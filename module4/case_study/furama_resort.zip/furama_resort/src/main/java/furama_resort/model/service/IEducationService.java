package furama_resort.model.service;

import furama_resort.model.entity.EducationEmployee;

import java.util.List;

public interface IEducationService {
    List<EducationEmployee> findAll();
}
