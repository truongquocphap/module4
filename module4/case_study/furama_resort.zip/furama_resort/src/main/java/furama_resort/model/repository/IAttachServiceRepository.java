package furama_resort.model.repository;

import furama_resort.model.entity.AttachService;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IAttachServiceRepository extends JpaRepository<AttachService,Integer> {
}
