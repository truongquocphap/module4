package furama_resort.model.service;

import furama_resort.model.entity.RentType;

import java.util.List;

public interface IRentTypeService {
    List<RentType> findAll();
}
