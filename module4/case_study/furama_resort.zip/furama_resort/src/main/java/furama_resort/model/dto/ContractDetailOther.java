package furama_resort.model.dto;

import furama_resort.model.entity.Contract;

public interface ContractDetailOther {
    Integer getContractDetailId();
    String getQuantity();
    Integer getContractId();
    String getAttachServiceName();
}
