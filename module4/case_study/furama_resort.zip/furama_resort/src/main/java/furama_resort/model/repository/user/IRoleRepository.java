package furama_resort.model.repository.user;

import furama_resort.model.entity.user.Role;
import org.springframework.data.repository.Repository;

public interface IRoleRepository extends Repository<Role,Integer> {

}
