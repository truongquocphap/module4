package furama_resort.model.service;

import furama_resort.model.entity.AttachService;

import java.util.List;

public interface IAttachServiceService {
    List<AttachService> findAll();
}
