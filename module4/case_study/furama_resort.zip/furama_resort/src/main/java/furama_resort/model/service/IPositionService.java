package furama_resort.model.service;

import furama_resort.model.entity.Position;

import java.util.List;

public interface IPositionService {
    List<Position> findAll();
}
